import random
#imports classes from other file in folder
from P5Classes import Treasure
from P5Classes import Armor
from P5Classes import Food
from P5Classes import Gold
from P5Classes import Weapon 
from P5Classes import Player


def GenerateGrid(): #randomly generates the levels with the min/max parameters
    treasure = {}
    min_w = 10
    max_w = 40 
    min_h = 10
    max_h = 25

    pieces = ['u', 'd', '.', 'P', 'M', '*'] #symbols that make up the "graphics"

    w = random.randrange(min_w, max_w)
    h = random.randrange(min_h, max_h)

    grid = '' #empty string for map to print and be stored

    for i in range(0, h):
        for j in range(0, w):

            if i == 0 or i == h-1 or j == 0 or j == w-1:
                item = '#' #determines where to print walls on the level
                
            else:            
                item = pieces[random.randrange(0, len(pieces))]
                if item == 'P':
                    pieces.remove('P')
                elif item == 'u':
                    pieces.remove('u') 
                elif item == 'd':
                    pieces.remove('d')
                elif item == '*': #removes any characters generated that are in use as other things
                    rng = random.randrange(0, 4)
                    if rng == 0: #uses random number generator to determine which type of item to place
                        t = Armor()
                    elif rng == 1:
                        t = Weapon()
                    elif rng == 2:
                        t = Food()
                    elif rng == 3:
                        t = Gold()

                    t.setloc(i, j)
                    treasure[str(i)+'-'+str(j)] = [t]
                    
            grid += item
                
        grid += "\n"

    return [grid, treasure] #returns complete level grid

def init():
    worlds = [1] 

    def down_level(worlds): #function to move up level
        worlds[0] += 1
        if len(worlds) <= worlds[0]:
            worlds.append(GenerateGrid())
        print('Level', worlds[0]) 
        print(worlds[worlds[0]][0])
        return True

    def up_level(worlds): #function to move down level
        worlds[0] -= 1
        print(worlds[0])
        if worlds[0] <= 0:
            return False
        print('Level', worlds[0])
        print(worlds[worlds[0]][0])
        return True
    
    worlds.append(GenerateGrid())
    print('Level', worlds[0])
    print(worlds[1][0]) #appends the generated level to the list

    bob = Player()
    last_tile = '.'
    the_world = worlds[worlds[0]][0]
    the_treasure = worlds[worlds[0]][1]

    def find_player(world): #function written to find player in world, printing the error if one cannot be found

        if 'P' in world:
            it = True
        else:
            it = False
            
        for h, r in enumerate(world.split("\n")):           
            for w, c in enumerate(r):                       
                if it:                                      
                    if c == 'P': #if player found, P is displayed in correct location
                        print('player found')
                        return {'height':h, 'width':w}
                elif c == 'u': #if no player found, returns player not found
                    print('player not found')
                    return {'height':h, 'width':w}

    def update_tile(world, h, w, tile): #function to update tile when things change, such as player moving or item being picked up
        it = world.split("\n") #splits string and uses new line
        s = list(it[h])
        s[w] = tile 
        it[h] = "".join(s)
        return "\n".join(it) 

    def get_tile(world, h, w):
        it = world.split("\n")
        return it[h][w] #returns the position of a specific tile

    bob.move_to(find_player(the_world))
    
    running = True #sets running to true to start loop
    while(running):        #loop to keep the game running after each command

        move = False
        hadj = 0
        wadj = 0
        loc = bob.get_loc()
        
        a = input("What is your command: ")
            #player functions, movement and inventory and help
        if a == '?':
            print('h: move to the left (West)')
            print('j: move down (South)')
            print('k: move up (North)')
            print('l: move to the right (East)')
            print('i: check inventory')

        if a == 'quit' or a == 'exit':
            running = False
            
        elif a == 'h':
            move = True
            wadj = -1
        elif a == 'j':
            move = True
            hadj = 1
        elif a == 'k':
            move = True
            hadj = -1
        elif a == 'l':
            move = True
            wadj = 1
        elif a == 'i':
            print(bob.inventory())
        elif a == 'v':
            if last_tile != 'd': #prints message if player tries to go up a non staircase
                print('This is not a downward bound staircase')
            else:
                worlds[worlds[0]][0] = update_tile(the_world, loc['height'], loc['width'], last_tile)
                running = down_level(worlds) #if not a staircase, changes player location to designated direction
                if not running:
                    return
                the_world = worlds[worlds[0]][0] #generates new world upon going up a staircase
                the_treasure = worlds[worlds[0]][1]
                last_tile = '.'
                bob.move_to(find_player(the_world))
                loc = bob.get_loc()
                worlds[worlds[0]][0] = update_tile(the_world, loc['height'], loc['width'], 'P')
                the_world = worlds[worlds[0]][0]
            
        elif a == '^': #prints message if player tries to go down a non downward staircase
            if last_tile != 'u':
                print('This is not an upward bound staircase')
            else:
                worlds[worlds[0]][0] = update_tile(the_world, loc['height'], loc['width'], last_tile)
                running = up_level(worlds)
                if not running:
                    return
                #returns previous level if player descends staircase
                the_world = worlds[worlds[0]][0]
                the_treasure = worlds[worlds[0]][1]
                last_tile = '.'
                bob.move_to(find_player(the_world)) 
                loc = bob.get_loc()
                worlds[worlds[0]][0] = update_tile(the_world, loc['height'], loc['width'], 'P')
                the_world = worlds[worlds[0]][0]
            
            
        if move: #function to change player location if move

            nh = loc['height']+hadj
            nw = loc['width']+wadj

            tile = get_tile(the_world, nh, nw)

            if tile == '#': #stops player from moving through walls
                print('Cannot move there, that is a wall') 
                
            else:
                bob.move_to({'height':nh, 'width':nw}) #if target is not wall, player moves to new location
                worlds[worlds[0]][0] = update_tile(the_world, nh, nw, 'P')
                the_world = worlds[worlds[0]][0]
                worlds[worlds[0]][0] = update_tile(the_world, loc['height'], loc['width'], last_tile)
                the_world = worlds[worlds[0]][0]

            last_tile = tile

            print('Level', worlds[0])
            print(the_world) #prints level every time it is updated

init() #calls init function

print('Terminated')
