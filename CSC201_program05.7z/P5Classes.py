
class Treasure: #parent class

    valid_holders = ['player', 'monster', 'none']

    treasure_type = 'none'

    gold_value = 0

    location = None
    
    carried = 'none'

    description = 'nothing' #sets all variables for class to none

    #functions that define the class

    def setloc(self, h, w):
        self.location = {'height':h, 'width':w} #determines the location of the treasure

    def pickup(self): 
        return "You picked up" + self.name 
        
    def drop(self, location):
        self.location = location
        return "You dropped" + self.name #drops item at location of the player

    def wear(self):
        return "You cannot wear" + self.name 

    def remove(self):
        return "You are not wearing" + self.name 

    def wield(self):
        return "You cannot wield" + self.name   

    def unwield(self):
       return "You are not wielding" + self.name

    def eat(self):
        return "You cannot eat" + self.name 

    def lookat(self):
        return self.description #returns description of self at current time    

    def getType(self):
        return self.treasure_type #returns treasure type

    def getWorth(self):
        return self.gold_value #returns gold value of item

class Armor(Treasure):

    worn = False

    def __init__(self):
        self.treasure_type = "armor"

    def wear(self): #allows you to wear armor if nothing is currently being worn
        if self.worn == True:
            return "You are already wearing" + self.description
        else:
            self.worn = True
            return "You are now wearing" + self.description

    def remove(self): #removes armor currently worn by player
        if self.worn == False:
            return "You are no wearing" + self.description
        else:
            return "You are no longer wearing" + self.description

class Food(Treasure):

    def __init__(self):
        self.treasure_type = "food" #allows you to eat item if treasure type is food

    def eat(self):
        return "You have eaten" + self.description

class Gold(Treasure):

    def __init__(self):
        self.treasure_type = "gold" 

    def lookat(self): #returns string of gold value if treasure type is gold
        return str(self.gold_value)

class Weapon(Treasure):

    wielded = False

    def __init__(self):
        self.treasure_type = "weapon" #determines weapon type

    def wield(self): #wields weapon if none is currently being held
        if self.wielded == True:
            return "You are already wielding" + self.description
        else:
            self.wielded = True
            return "You are now wielding" + self.description

    def unwield(self):
        if self.wielded == False: #unwields weapon if one is currently held
            return "You are not wielding" + self.description
        else:
            self.wielded = False
            return "You are no longer wielding" + self.description

class Player:

    nothing = None

    name = "nobody"
    
    lvl = 0
    
    hp = 0
    
    df = 0
    itemworn = nothing
    
    atk = 0
    itemwielded = nothing
    
    storage = [] 
    location = None
    #sets player variables and storage before functions so that they may be manipulated

    def __init__(self):
        self.storage.append(Gold()) #appends gold amount to storage
        self.nothing = Treasure()
        
    def look_at(self):
        if hp < 3: #if health under 3, adds not to returned state "healthy"
            state = "not"
        else:
            state = "" #blank space so function returns state "healthy"
            
        return "An adventurer named "+self.name+", wearing "+self.itemworn.lookat()+" and wielding "+self.itemwielded.lookat()+". "+self.name+" is "+state+" healthy."

    def move_to(self, pos):
        self.location = pos #changes player position to designated position

    def get_loc(self):
        return self.location #returns current location of player

    def inventory(self):
        items = "" 
        for i, item in enumerate(self.storage): #goes through items in player storage and gets type
            if item.getType() == 'gold':
                items += str(i+1)+". "+item.lookat()+" gold coins\n"
            elif item == self.itemworn:
                items += str(i+1)+". "+item.lookat()+" (worn)\n"
            elif item == self.itemwielded:
                items += str(i+1)+". "+item.lookat()+" (wielded)\n"
            else:
                items += str(i+1)+". "+item.lookat()+"\n" #tells how many coins/if an item is worn or wielded by the player
        return items

    def equip(self): 
        armor = False
        weapon = False
        result = ""
        for item in self.storage:
            
            if item.getType() == 'armor' and armor == False: #checks item type and if player has it equipped
                result += item.equip()
                self.itemworn = item  #equips the item
                # increase defense
                armor = True
                    
            elif item.getType() == 'weapon' and weapon == False: #checks if item type is weapon
                result += item.wield()
                self.itemwielded = item
                # increase dmg
                weapon = True

            if weapon and armor:
                return result
            

    def remove(self): #removes armor if equipped
        if self.itemworn.getType() == 'armor':
            self.itemworn = self.nothing 
            return self.itemworn.remove()
        else:
            return "You are not wearing any armor"

    def unwield(self): #removes weapon if equipped
        if self.itemwielded.getType() == 'weapon':
            self.itemwielded = self.nothing
            return self.itemwielded.unwield()
        else:
            return "You are not wielding any armor"

    def eat(self, index): #eats specified item if item can be eaten
        return self.storage[index].eat()
        
    
    def drop(self, index): #drops specified item
        name = self.storage[index].lookat()
        self.storage.remove(index)
        return "You have droped "+name

